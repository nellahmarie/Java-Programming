public class Chevy extends Auto
{
   public void setprice()
   {  
      this.price = 22000;
   }
}