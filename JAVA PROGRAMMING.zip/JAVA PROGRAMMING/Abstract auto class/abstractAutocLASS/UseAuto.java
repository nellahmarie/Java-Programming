import java.util.*;
import java.util.Scanner;
public class UseAuto
{
   public static void main(String args[])
   {
      Scanner sc = new Scanner(System.in);
         Ford ford = new Ford();
         System.out.print("Enter Ford Car name: ");
         ford.setCar(sc.nextLine());
        
         
         Chevy chev = new Chevy();
         System.out.print("Enter Chevy Car name: ");
         chev.setCar(sc.nextLine());
         
         
         System.out.println("Ford Car: " + ford.getCar());
         System.out.println("Price: " + ford.getPrice());
         System.out.println("Chevy Car: " + chev.getCar());
         System.out.println("Price: " + chev.getPrice());
   }
}