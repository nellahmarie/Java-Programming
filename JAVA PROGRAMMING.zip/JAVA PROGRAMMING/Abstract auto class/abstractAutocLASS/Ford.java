public class Ford extends Auto
{
   public void setprice()
   {  
      
   }
}