public abstract class Auto
{
   public string car;
   public double price
   
   public abstract setprice();
   
   public void setPrice(double price)
   {
      this.price=price;
   }
   public double getPrice()
   {
      return price;
   }
   public void setCar(string car)
   {
      this.car=car;
   }
   public double getCar()
   {
      return car;
   }
}