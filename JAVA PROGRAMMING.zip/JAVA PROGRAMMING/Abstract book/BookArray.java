import java.util.Scanner;
public class BookArray {
    public static void main(String[] args) {
       /* Book[] books = new Book[10];
        books[0] = new Fiction("The Great Gatsby");
        books[1] = new NonFiction("The Origin of Species");
        books[2] = new Fiction("To Kill a Mockingbird");
        books[3] = new NonFiction("Silent Spring");
        books[4] = new Fiction("The Catcher in the Rye");
        books[5] = new NonFiction("The Immortal Life of Henrietta Lacks");
        books[6] = new Fiction("1984");
        books[7] = new NonFiction("Thinking, Fast and Slow");
        books[8] = new Fiction("Brave New World");
        books[9] = new NonFiction("The Selfish Gene");

        for (int i = 0; i < books.length; i++) {
            System.out.println("Book " + (i+1) + " title: " + books[i].getTitle());
            System.out.println("Book " + (i+1) + " price: " + books[i].getPrice());
            System.out.println();
        }*/
        
        
        Scanner sc = new Scanner(System.in);

        Book[] books = new Book[10];
        
        for (int i = 0; i < 10; i++) 
        {
            System.out.print("Enter the title of book " + (i+1) + ": ");
            String title = sc.nextLine();

            if (i % 2 == 0)
            {
                books[i] = new Fiction(title);
            } 
            else 
            {
                books[i] = new NonFiction(title);
            }
        }

        for (int i = 0; i < books.length; i++)
        {
            System.out.println("Book " + (i+1) + " title: " + books[i].getTitle());
            System.out.println("Book " + (i+1) + " price: " + books[i].getPrice());
            System.out.println();
        }

        sc.close();
    }
}
