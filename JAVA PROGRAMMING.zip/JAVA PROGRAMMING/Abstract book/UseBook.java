import java.util.Scanner;

public class UseBook
{
   public static void main(String args[])
   {
       /* Fiction f = new Fiction("The Great Gatsby");
        System.out.println("Fiction book title: " + f.getTitle());
        System.out.println("Fiction book price: " + f.getPrice());
        
        NonFiction Nf = new NonFiction("The Origin of Species");
        System.out.println("Non-fiction book title: " + Nf.getTitle());
        System.out.println("Non-fiction book price: " + Nf.getPrice());*/
        

        
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the title of a fiction book: ");
        String fictionTitle = sc.nextLine();
        Fiction f = new Fiction(fictionTitle);
        
        System.out.println("Fiction book title: " + f.getTitle());
        System.out.println("Fiction book price: " + f.getPrice());

        System.out.print("Enter the title of a non-fiction book: ");
        String nonFictionTitle = sc.nextLine();
        NonFiction Nf = new NonFiction(nonFictionTitle);
        
        System.out.println("Non-fiction book title: " + Nf.getTitle());
        System.out.println("Non-fiction book price: " + Nf.getPrice());

        sc.close();
        
        
   }
}