public abstract class Account
{
  public int accountNo;
  public double accountBalance;
  
  public abstract double getAccountBalance();
  public abstract int getAccountNo();
  
   public Account(int accountNo)
   {
      this.accountNo = accountNo;
      this.accountBalance = 0.0;
   }
   
   public void setAccountBalance(double accountBalance)
   {
      this.accountBalance = accountBalance;
   }
   
  
   
   
   
}