import java.util.Scanner;

public class AccountArray 
{
    public static void main(String[] args) 
    {
        Account[] accounts = new Account[10];

        Scanner scanner = new Scanner(System.in);

        for (int i = 0; i < accounts.length; i++) 
        {
            System.out.println("Enter account type (C for checking, S for savings): ");
            String accountType = scanner.next();

            System.out.println("Enter account number: ");
            int accountNumber = scanner.nextInt();

            if (accountType.equalsIgnoreCase("C")) 
            {
                accounts[i] = new Checking(accountNumber);
            } 
            else if (accountType.equalsIgnoreCase("S")) 
            {
                System.out.println("Enter interest rate: ");
                double interestRate = scanner.nextDouble();
                accounts[i] = new Savings(accountNumber, interestRate);
            }

            System.out.println("Enter account balance: ");
            double accountBalance = scanner.nextDouble();
            accounts[i].setAccountBalance(accountBalance);
        }

        for (int i = 0; i < accounts.length; i++) 
        {
            if (accounts[i] instanceof Checking) 
            {
                ((Checking) accounts[i]).displayAccountInfo();
            } 
            else if (accounts[i] instanceof Savings) 
            {
                ((Savings) accounts[i]).displayAccountInfo();
            }
        }
    }
}