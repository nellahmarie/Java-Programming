import java.util.*;

public class DemoAccounts 
{
    public static void main(String[] args)
     {
        Checking checking = new Checking(1001);
        checking.setAccountBalance(5000.0);
        checking.displayAccountInfo();

        Savings savings = new Savings(2001, 2.5);
        savings.setAccountBalance(10000.0);
        savings.displayAccountInfo();
    }
}