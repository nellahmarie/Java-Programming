public class Savings extends Account
{
   double interestRate;
   
   public Savings(int accountNo, double interestRate)
   {
      super(accountNo);
      this.interestRate = interestRate;
   }
   
   public int getAccountNo()
   {
      return this.accountNo;
   }
   
   public double getAccountBalance()
   {
      return this.accountBalance;
   }
    public void displayAccountInfo() 
    {
        System.out.println("Savings Account Information: ");
        System.out.println("Account Number: " + this.getAccountNo());
        System.out.println("Account Balance: $" + this.getAccountBalance());
        System.out.println("Interest Rate: " + interestRate + "%");
    }
}