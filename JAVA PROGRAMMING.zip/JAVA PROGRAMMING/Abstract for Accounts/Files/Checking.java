public class Checking extends Account
{
   public Checking(int accountNo)
   {
      super(accountNo);  
   }
   
   public int getAccountNo()
   {
      return this.accountNo;
   }
   
   public double getAccountBalance()
   {
      return this.accountBalance;
   }
   
   public void displayAccountInfo()
   {
        System.out.println("Checking Account Information: ");
        System.out.println("Account Number: " + this.accountNo);
        System.out.println("Account Balance: $" + this.accountBalance);
    }
}
