import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.*;
import java.util.Scanner;
public class UseOrder
{
   public static void main(String[] args) {
      
      Scanner sc = new Scanner(System.in);

       Order order = new Order();
       System.out.println("Order:");
       System.out.print("Enter customer name: ");
       order.setCustomerName(sc.nextLine());
       System.out.print("Enter customer number: ");
       order.setCustomerNumber(sc.nextInt());
       System.out.print("Enter quantity ordered: ");
       order.setQuantityOrdered(sc.nextInt());
       System.out.print("Enter unit price: $");
       order.setUnitPrice(sc.nextDouble());
       order.computePrice();
       order.display();

   Scanner sh = new Scanner(System.in);

       ShippedOrder shippedOrder = new ShippedOrder();
       System.out.println("Enter details for Shipped Order:");
       System.out.print("Enter customer name: ");
       shippedOrder.setCustomerName(sh.next());
       System.out.print("Enter customer number: ");
         while (!sh.hasNextInt()) {
             System.out.println("Invalid input. Please enter a valid integer.");
             sh.nextLine();
         }
         shippedOrder.setCustomerNumber(sh.nextInt());
       System.out.println("customer number: " + shippedOrder.getcustomerNumber());
       System.out.print("Enter quantity ordered: ");
       shippedOrder.setQuantityOrdered(sh.nextInt());
       System.out.print("Enter unit price: $");
       shippedOrder.setUnitPrice(sh.nextDouble());
       shippedOrder.computePrice();
       shippedOrder.display();

        

    }
}