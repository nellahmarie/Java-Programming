class Order
{
    public String customerName;
    public int customerNumber;
    public int quantityOrdered;
    public double unitPrice;
    public double totalPrice;
    
   /* public Order(String customerName, int customerNumber, int quantityOrdered, double unitPrice, double totalPrice)
    {
      this.customerName =customerName;
      this.customerNumber = customerNumber;
      this.quantityOrdered = quantityOrdered;
      this.unitPrice = unitPrice;
      this.totalPrice=totalPrice;
    }*/

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setCustomerNumber(int customerNumber) {
        customerNumber = customerNumber;
    }

    public void setQuantityOrdered(int quantityOrdered) {
        this.quantityOrdered = quantityOrdered;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public void computePrice() {
        totalPrice = quantityOrdered * unitPrice;
    }
    
    public String getCustomerName()
    {
      return this.customerName;
    }
    public int getcustomerNumber()
    {
      return this.customerNumber;
    }
    public int getquantityOrdered()
    {
      return this.quantityOrdered;
    }
    public double getunitPrice()
    {
      return unitPrice;
    }
    public double getTotalPrice()
    {
      return totalPrice;
    }
    

    public void display() {
        System.out.println("Customer Name: " + this.customerName);
        System.out.println("Customer Number: " + this.customerNumber);
        System.out.println("Quantity Ordered: " + this.quantityOrdered);
        System.out.println("Unit Price: $" + this.unitPrice);
        System.out.println("Total Price: $" + this.totalPrice);
        }
}