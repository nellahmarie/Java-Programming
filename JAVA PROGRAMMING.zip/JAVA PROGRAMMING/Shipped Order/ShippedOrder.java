class ShippedOrder extends Order
{
   
    @Override
    public void computePrice() {
        super.computePrice();
        this.totalPrice += 4.00;
    }

}