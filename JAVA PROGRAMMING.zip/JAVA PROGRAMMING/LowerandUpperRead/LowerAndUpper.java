import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class LowerAndUpper {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String lowerFileName = "lowerclassman.txt";
        String upperFileName = "upperclassman.txt";
        int lowerLimit = 60;
        FileWriter lowerWriter = null;
        FileWriter upperWriter = null;

        try {
            lowerWriter = new FileWriter(lowerFileName);
            upperWriter = new FileWriter(upperFileName);

            System.out.println("Enter student information. Enter 0 to quit.");
            while (true) {
                System.out.print("Enter student ID: ");
                int id = input.nextInt();

                if (id == 0) {
                    break;
                }

                System.out.print("Enter student first name: ");
                String firstName = input.next();

                System.out.print("Enter student last name: ");
                String lastName = input.next();

                System.out.print("Enter credit hours completed: ");
                int creditHours = input.nextInt();

                Student student = new Student(id, firstName, lastName, creditHours);

                if (student.getCreditHours() < lowerLimit) {
                    lowerWriter.write(student.toString() + "\n");
                } else {
                    upperWriter.write(student.toString() + "\n");
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        } finally {
            try {
                if (lowerWriter != null) {
                    lowerWriter.close();
                }
                if (upperWriter != null) {
                    upperWriter.close();
                }
            } catch (IOException e) {
                System.out.println("An error occurred while closing the file.");
                e.printStackTrace();
            }
        }
    }
}
