public class Student
{
   public int studentId;
   public String firstName;
   public String lastName;
   public int Credithours;
   
   public Student(int studentId, String firstName, String lastName, int Credithours)
   {
      this.studentId=studentId;
      this.firstName=firstName;
      this.lastName = lastName;
      this.Credithours=Credithours;
   }
   
    public void displayRecord()
    {
        System.out.println("ID: " + studentId);
        System.out.println("Name: " + firstName + " " + lastName);
        System.out.println("Credit Hours: " + Credithours);
    }
    
    public int getID()
    {
      return studentId;
    }
    public String getFirstName()
    {
      return firstName;
    }
    public String getLastName()
    {
      return lastName;
    }
    
    public int getCreditHours()
    {
        return Credithours;
    }
    public String toString() {
        return studentId + "\t" + lastName + ", " + firstName + "\t" + Credithours;
    }
}