import java.util.Scanner;
import java.io.*;

public class LowerAndUpperRead {
    public static void main(String[] args) {
        String lowerFileName = "lowerclassman.txt";
        String upperFileName = "upperclassman.txt";
        File lowerFile = new File(lowerFileName);
        File upperFile = new File(upperFileName);
        Scanner lowerReader = null;
        Scanner upperReader = null;

        try {
            System.out.println("Lowerclassmen:");
            lowerReader = new Scanner(lowerFile);
            while (lowerReader.hasNextLine()) {
                String line = lowerReader.nextLine();
                Student student = parseStudent(line);
                System.out.println("Student ID: " + student.getID());
                System.out.println("Name: " + student.getLastName() + ", " + student.getFirstName());
                System.out.println("Credit Hours: " + student.getCreditHours());
                System.out.println();
            }

            System.out.println("Upperclassmen:");
            upperReader = new Scanner(upperFile);
            while (upperReader.hasNextLine()) {
                String line = upperReader.nextLine();
                Student student = parseStudent(line);
                System.out.println("Student ID: " + student.getID());
                System.out.println("Name: " + student.getLastName() + ", " + student.getFirstName());
                System.out.println("Credit Hours: " + student.getCreditHours());
                System.out.println();
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found.");
            e.printStackTrace();
        } finally {
            if (lowerReader != null) {
                lowerReader.close();
            }
            if (upperReader != null) {
                upperReader.close();
            }
        }
    }

    private static Student parseStudent(String line) {
        String[] parts = line.split("\\s+");
         int id = Integer.parseInt(parts[0]);
         String firstName = parts[1].trim();
         String lastName = parts[2].trim();
         int creditHours = Integer.parseInt(parts[3]);

        return new Student(id, firstName, lastName, creditHours);
    }
}
