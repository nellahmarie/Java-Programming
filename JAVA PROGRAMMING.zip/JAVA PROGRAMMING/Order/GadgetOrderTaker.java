import java.util.ArrayList;
import java.util.Scanner;

public class GadgetOrderTaker {
    private static final Gadget[] gadgets = {
        new Gadget(101, "Electric Hand Warmer", 12.99),
        new Gadget(124, "Battery Operated plant waterer", 7.55),
        new Gadget(256, "Gerbil Trimmer", 9.99),
        new Gadget(512, "Taliking Bookmark", 6.89)
    };

    public static void main(String[] args) throws OrderException {
        Scanner scanner = new Scanner(System.in);

        ArrayList<Order> orders = new ArrayList<>();

        for (int i = 0; i < 4; i++) {
            int orderNumber = 101 + i;

            System.out.print("Enter your name: ");
            String customerName = scanner.nextLine();

            System.out.print("Enter your street address: ");
            String address = scanner.nextLine();

            ArrayList<Integer> itemNumbers = new ArrayList<>();
            ArrayList<Integer> quantities = new ArrayList<>();

            while (itemNumbers.size() < 4) {
                System.out.print("Enter an item number (999 to finish): ");
                String itemNumberStr = scanner.nextLine();

                if (itemNumberStr.equals("999")) {
                    break;
                }

                int itemNumber;

                try {
                    itemNumber = Integer.parseInt(itemNumberStr);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid item number.");
                    continue;
                }

                Gadget gadget = null;

                for (Gadget g : gadgets) {
                    if (g.getItemNumber() == itemNumber) {
                        gadget = g;
                        break;
                    }
                }

                if (gadget == null) {
                    System.out.println("Invalid item number.");
                    continue;
                }

                System.out.print("Enter quantity: ");
                String quantityStr = scanner.nextLine();

                int quantity;

                try {
                    quantity = Integer.parseInt(quantityStr);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid quantity.");
                    continue;
                }

                if (quantity > 100) {
                    System.out.println("Quantity cannot be greater than 100.");
                    continue;
                }

                itemNumbers.add(itemNumber);
                quantities.add(quantity);
            }

            double totalPrice = 0;

            for (int j = 0; j < itemNumbers.size(); j++) {
                int itemNumber = itemNumbers.get(j);
                int quantity = quantities.get(j);

                Gadget gadget = null;

                for (Gadget g : gadgets) {
                    if (g.getItemNumber() == itemNumber) {
                        gadget = g;
                        break;
                    }
                }

                if (gadget == null) {
                    throw new OrderException("Invalid item number.");
                }

                totalPrice += gadget.getPrice() * quantity;
            }

            double shippingAndHandling = 0;

            if (totalPrice >= 0 && totalPrice <= 24.99) {
                shippingAndHandling = 5.55;
            } else if (totalPrice >= 25 && totalPrice <= 49.99) {
                shippingAndHandling = 8.55;
            } else if (totalPrice > 50) {
                shippingAndHandling = 11.55;
            }

            Order order = new Order(orderNumber, customerName, address, itemNumbers, totalPrice, shippingAndHandling);

            orders.add(order);
        }

        for (Order order : orders) {
            System.out.println(order.toString());
        }
    }
}
