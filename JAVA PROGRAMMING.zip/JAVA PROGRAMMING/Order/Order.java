import java.util.ArrayList;
import java.util.List;

public class Order {
    private int orderNumber;
    private String customerName;
    private String address;
    private List<Integer> itemNumbers;
    private double totalPrice;
    private double shippingAndHandlingFee;
    
    public Order(int orderNumber, String customerName, String address, List<Integer> itemNumbers, double totalPrice, double shippingAndHandlingFee) {
    this.orderNumber = orderNumber;
    this.customerName = customerName;
    this.address = address;
    this.itemNumbers = itemNumbers;
    this.totalPrice = totalPrice;
    this.shippingAndHandlingFee = shippingAndHandlingFee;
}
    
    public int getOrderNumber() {
        return orderNumber;
    }
    
    public String getCustomerName() {
        return customerName;
    }
    
    public String getAddress() {
        return address;
    }
    
    public List<Integer> getItemNumbers() {
        return itemNumbers;
    }
    
    public double getTotalPrice() {
        return totalPrice;
    }
    
    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
    
    public double getShippingAndHandlingFee() {
        return shippingAndHandlingFee;
    }
    
    public void setShippingAndHandlingFee(double shippingAndHandlingFee) {
        this.shippingAndHandlingFee = shippingAndHandlingFee;
    }
    
    public void addItemNumber(int itemNumber) {
        itemNumbers.add(itemNumber);
    }
    
    public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("Order Number: ").append(orderNumber).append("\n");
    sb.append("Customer Name: ").append(customerName).append("\n");
    sb.append("Address: ").append(address).append("\n");
    sb.append("Item Numbers: ").append(itemNumbers).append("\n");
    sb.append("Total Price: ").append(totalPrice).append("\n");
    sb.append("Shipping and Handling Fee: ").append(shippingAndHandlingFee).append("\n");
    return sb.toString();
}

}
