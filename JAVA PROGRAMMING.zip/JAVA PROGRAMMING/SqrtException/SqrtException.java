import java.util.*;
import java.util.Scanner;
import java.lang.Math;
public class SqrtException
{
   public static void main(String[] args)
   {
      Scanner sc = new Scanner(System.in);
      
      
      try
      {
         
         System.out.println("Enter any number: ");
             int  num = sc.nextInt();
     
        if(num < 0)
        {
          throw(new ArithmeticException());
		  } 
        else
        {
            
          System.out.println("The square root of " + num + " is " + (int)Math.sqrt(num));

        } 
      
      }
      catch(ArithmeticException e)
      {
         System.out.println("Error try again ");
      }
      
   }
}