import java.util.*;
public class DataEntryException extends Exception
{
   public DataEntryException(String message)
   {
      super(message);
   }
}