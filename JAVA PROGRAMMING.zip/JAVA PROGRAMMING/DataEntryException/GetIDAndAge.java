import java.util.*;
public class GetIDAndAge
{
   public static void main(String[] args)
   {
      int Id;
      int age;
    while(true)
    {  
        try
        {   
         Scanner sc = new Scanner(System.in);
            
            System.out.println("Enter your ID: ");
            Id = sc.nextInt();
            System.out.println("Enter your age: ");
            age = sc.nextInt();
              
            if(Id == 0 && age == 0)
            {
               break;
            }
            else  if(Id < 0 || Id > 999 && age == 0 || age >119)
            {
               throw new DataEntryException("Error: Invalid");
            }
            
            
            System.out.println("ID: " + Id + "\nAge: " + age);
             
            
         }
         catch(DataEntryException e)
         {
            System.out.println(e.getMessage());
         } 
         catch(InputMismatchException e)
         {
            System.out.println("Error: Input is "+e.getMessage());
         }
    }
  
     
   }
}