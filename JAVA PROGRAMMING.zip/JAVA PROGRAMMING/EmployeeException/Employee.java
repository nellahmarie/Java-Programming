public class Employee {
    public String idNum;
    public double hourlyWage;

    public Employee(String idNum, double hourlyWage) throws EmployeeException 
    {
        if (hourlyWage < 6.0 || hourlyWage > 50.0) 
        {
            throw new EmployeeException("Invalid hourly wage: " + hourlyWage);
        }
        this.idNum = idNum;
        this.hourlyWage = hourlyWage;
        System.out.println("Employee created successfully: " + idNum);
    }

    // Getter and setter methods
    public void setIdNum(String IdNum)
    {
       this.idNum = idNum;
    }
    public String getIdNuM()
    {
      return idNum;
    }
    public void sethourlyWage(double hourlyWage)
    {
       this.hourlyWage = hourlyWage;
    }
    public double gethourlyWage()
    {
      return hourlyWage;
    }
}
