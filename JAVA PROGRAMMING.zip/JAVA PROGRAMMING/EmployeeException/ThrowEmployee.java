import java.util.*;
import java.util.Scanner;
public class ThrowEmployee
{
    public static void main(String[] args) 
    {
        try 
        {
            Employee emp1 = new Employee("1001", 4.0); // Should throw an exception
        } 
        catch (EmployeeException e) 
        {
            System.out.println("Failed to create employee: " + e.getMessage());
        }

        try 
        {
            Employee emp2 = new Employee("1002", 10.0); // Should create employee successfully
        } 
        catch (EmployeeException e) 
        {
            System.out.println("Failed to create employee: " + e.getMessage());
        }

        try 
        {
            Employee emp3 = new Employee("1003", 60.0); // Should throw an exception
        } 
        catch (EmployeeException e) 
        {
            System.out.println("Failed to create employee: " + e.getMessage());
        }
        

    }
}
