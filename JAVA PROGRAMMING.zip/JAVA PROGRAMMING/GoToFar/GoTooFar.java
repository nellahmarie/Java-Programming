public class GoTooFar{

   public static void main(String args[])
   {
      
      int[] num = {1,2,3,4,5};
      int x =0;
         try
         {
         
            while(true)
            {
               System.out.println(x +": " + num[x]);
               x++;
            }
            
         }
         catch(ArrayIndexOutOfBoundsException e)
         {
            System.out.println("Error ");
         }
   
   }
}