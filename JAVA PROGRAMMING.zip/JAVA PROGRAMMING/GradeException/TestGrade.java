import java.util.Scanner;

public class TestGrade 
{
    public static void main(String[] args) 
    {
        String[] studentIds = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10"};
        char[] grades = new char[studentIds.length];
        Scanner input = new Scanner(System.in);

        for (int i = 0; i < studentIds.length; i++) 
        {
            System.out.print("Enter grade for student " + studentIds[i] + ": ");
            char grade = input.next().charAt(0);
            try 
            {
                validateGrade(grade);
                grades[i] = grade;
            } 
            catch (GradeException ex) 
            {
                System.out.println(ex.getMessage());
                grades[i] = 'I';
            }
        }

        System.out.println("\nStudent Grades:\n");
        for (int i = 0; i < studentIds.length; i++) 
        {
            System.out.println(studentIds[i] + ": " + grades[i]);
        }
    }

    public static void validateGrade(char grade) throws GradeException 
    {
        for (char validGrade : GradeException.VALID_GRADES) 
        {
            if (grade == validGrade) 
            {
                return;
            }
        }
        throw new GradeException("Invalid grade entered. Valid grades are A, B, C, D, F, and I.");
    }
}
