import java.io.*;

public class ReadBackwards {
    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter some text: ");
            String input = reader.readLine();
            String reversed = new StringBuilder(input).reverse().toString();
            FileWriter writer = new FileWriter("output.txt");
            writer.write(reversed);
            writer.close();
            System.out.println(reversed);
            System.out.println("Text saved to output.txt.");
        } catch (IOException e) {
            System.out.println("An error occurred while reading/writing the file.");
            e.printStackTrace();
        }
    }
}
