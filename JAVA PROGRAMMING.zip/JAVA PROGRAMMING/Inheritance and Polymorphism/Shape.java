class Shape
{
   public static void main(String[] args)
   {
      
   }
}