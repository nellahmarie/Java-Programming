class Square
{
   public void draw()
   {
      System.out.println("Shape" + draw());
   }
   void erase() 
   {
      System.out.println (� Shape erase()�);
   }
}