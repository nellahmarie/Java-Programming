public class DataMessages {
    public static final String PART_NUMBER_NOT_NUMERIC = "Error: Part number must be numeric.";
    public static final String QUANTITY_NOT_NUMERIC = "Error: Quantity must be numeric.";
    public static final String PART_NUMBER_TOO_LOW = "Error: Part number cannot be less than 0.";
    public static final String PART_NUMBER_TOO_HIGH = "Error: Part number cannot be greater than 999.";
    public static final String QUANTITY_TOO_LOW = "Error: Quantity must be at least 1.";
    public static final String QUANTITY_TOO_HIGH = "Error: Quantity cannot be greater than 5000.";
}
