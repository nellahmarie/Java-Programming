import java.util.Scanner;

public class PartAndQuantityEntry 
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        boolean isValidEntry = false;
        while (!isValidEntry) 
        {
            System.out.print("Enter part number: ");
            String partNumberInput = scanner.nextLine();
            System.out.print("Enter quantity: ");
            String quantityInput = scanner.nextLine();
            try 
            {
                int partNumber = Integer.parseInt(partNumberInput);
                int quantity = Integer.parseInt(quantityInput);
                if (partNumber < 0) 
                {
                    throw new DataException(DataMessages.PART_NUMBER_TOO_LOW);
                }
                else if (partNumber > 999) 
                {
                    throw new DataException(DataMessages.PART_NUMBER_TOO_HIGH);
                } 
                else if (quantity < 1) 
                {
                    throw new DataException(DataMessages.QUANTITY_TOO_LOW);
                } 
                else if (quantity > 5000) 
                {
                    throw new DataException(DataMessages.QUANTITY_TOO_HIGH);
                } 
                else 
                {
                    System.out.println("Valid entry.");
                    isValidEntry = true;
                }
            } 
            catch (NumberFormatException e) 
            {
                System.out.println(DataMessages.PART_NUMBER_NOT_NUMERIC + " " + DataMessages.QUANTITY_NOT_NUMERIC);
            } 
            catch (DataException e) 
            {
                System.out.println(e.getMessage());
            }
        }
    }
}
