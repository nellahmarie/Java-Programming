import java.util.*;
public class TryToParseString
{
   public static void main(String args[])
   {
      
      try
      {
         Scanner s = new Scanner(System.in);
         System.out.print("Enter a number: "); 
         String num = s.nextLine();
         int n = Integer.parseInt(num);
         System.out.print("String converted into int: " + n ); 

      }
      catch(NumberFormatException e)
      {
         System.out.print("Error" ); 
      }
   }
}