import java.io.File;

public class SameFolder {
    public static void main(String[] args) {
        // Replace these with the file paths of the two files you want to check
        String filePath1 = "/Users/mariloucantilado/Desktop/SameFileFolder/1File.rtf";
        String filePath2 = "/Users/mariloucantilado/Desktop/SameFileFolder/2File.rtf";

        // Create File objects for the two files
        File file1 = new File(filePath1);
        File file2 = new File(filePath2);

        // Get the parent directory of each file
        File parent1 = file1.getParentFile();
        File parent2 = file2.getParentFile();

        // Compare the absolute paths of the parent directories
        if (parent1.getAbsolutePath().equals(parent2.getAbsolutePath())) {
            System.out.println("The two files are in the same folder.");
        } else {
            System.out.println("The two files are not in the same folder.");
        }
    }
}
