import java.util.*;
import java.util.Scanner;
public class NegativeArray
{
   public static void main(String args[])
   {
     try
     {
          Scanner sc = new Scanner(System.in);
          System.out.println("Enter a number to use as an array size: ");
          int num = Integer.parseInt(sc.nextLine());
          int[] arr = new int[num];
          
          System.out.println("Success ");
          
     }
     catch(NumberFormatException e)
     {   
         System.out.println("Error: Array number should be a number ");
     }
    catch(NegativeArraySizeException e)
     {   
         System.out.println("Error: Array number should not be negative number ");
     }
     
   }
}