import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.*;

abstract class Animal
{
   private int animalId;
   private String animalName;
   
   public abstract void animalSound();
   public void sleep()
   {
      System.out.println("Zzz");
   }
   public void sleep(int hours,String creature)
   {
      System.out.println(creature + " slept for " + hours +" hours...");
   }
   
   public void setName(String animalName)
   {
      this.animalName = animalName;
   }
   
   public String getName()
   {
      return animalName;
   }
   
   public void setId(int id)
   {
      this.animalId = id;
   }
   
   public int getId()
   {
      return animalId;
   }
}

class Dog extends Animal 
{
   public void animalSound()
   {
      System.out.println("The dog says: bark bark");
   }
   public void sleep()
   {
      System.out.println("Snore...");
   }
}

class Cat extends Animal
{
   public void animalSound()
   {
      System.out.println("The cat says: meow meow");
   }
}

class DogList
{
   private ArrayList<Dog> dogList = new ArrayList<Dog>();
   static String textFileLocation = "DogList.txt";
   
   public ArrayList<Dog> getList()
   {
      dogList.clear();
      try
      {
         File file = new File(textFileLocation);
         BufferedReader readFile = new BufferedReader(new FileReader(file));
         
         String read = "";
         int counter = 0;
         Dog newDog = new Dog();
         
         while((read = readFile.readLine()) != null)
         {
            if(counter == 0)
            {
               newDog.setId(Integer.parseInt(read.substring(8)));
            }
            else if(counter == 1)
            {
               newDog.setName(read.substring(6));
            }
            else if(counter == 2)
            {
               dogList.add(newDog);
               newDog = new Dog();
               counter= -1;
            }
            
            counter++;
            System.out.println(read);
         }
      }
      catch(Exception ex)
      {
         System.out.println(ex.toString());
      }
      
      return this.dogList;
   }
   
   public int getIndex(int id)
   {
      int found = -1;
      
      //System.out.println(dogList.size());

      for(int counter = 0; counter < this.dogList.size(); counter++)
      {
      
      //System.out.println("hello");
      //System.out.println(dogList.get(counter).getId());
      //System.out.println(id);
      
         if(this.dogList.get(counter).getId() == id)
         {
            found = counter;
            break;
         }
      }
      
      return found;
   }
   
   public Dog getDogs(int index)
   {
      return this.dogList.get(index);
   }
}

class TextFileManager 
{
   static String dogFileLocation = "DogList.txt";
   static String catFileLocation = "CatList.txt";
   
   public static void PutTextToTextFileDog(ArrayList<Dog> dog)
   {
      StringBuilder st = new StringBuilder();
      
      try
      {
         FileWriter write = new FileWriter(dogFileLocation);
         
         for(Dog indeDog: dog)
         {
            st.append("Dog ID: "+indeDog.getId()+"\n");
            st.append("Name: "+indeDog.getName()+"\n");
            st.append("============================== \n");
         }
         
         write.write(st.toString());
         write.flush();
         
      }
      catch(Exception e)
      {
         System.out.println(e.getMessage());
      }
   }
   
   public static void ViewTextFileEntriesDog()
   {
      try
      {
         File file = new File(dogFileLocation);
         BufferedReader readFile = new BufferedReader(new FileReader(file));
         
         String read = "";
         while((read = readFile.readLine()) != null)
         {
            System.out.println(read);
         }
      }
      catch(Exception ex)
      {
         System.out.println(ex.toString());
      }
   }
}

class Main 
{
   static Scanner myScanner = new Scanner(System.in);
   
   public static void main(String[] args)
   {
      //Dog myDog= new Dog();
      //Cat myCat= new Cat();
      
      //myDog.animalSound();
      //myDog.sleep();
      //myDog.setName("Browny");
      //System.out.println(myDog.getName());
      
      //System.out.println("");
      
      //myCat.animalSound();
      //myCat.sleep(11,"Kitty");
      //myCat.sleep();
      //myCat.setName("Noelle");
      //System.out.println(myCat.getName());
      
      String dogId;
      String dogName;
      char selection;
      DogList dogL = new DogList();
      
      ArrayList<Dog> subArrayDog = new ArrayList<Dog>();
      
      do
      {
         System.out.println("1. Dog List");
         System.out.println("2. Cat List");
         System.out.println("3. Exit");
         selection = myScanner.next().charAt(0);
         
         if(selection == '1')
         {
            do
            {
               System.out.println("1. Add");
               System.out.println("2. View");
               System.out.println("3. Update");
               System.out.println("4. Delete");
               System.out.println("5. Exit");
               selection = myScanner.next().charAt(0);
               
               if(selection == '1')
               {
                  System.out.println("Enter how many dogs: ");
                  int numOfDogs = myScanner.nextInt();
                  myScanner.nextLine();
                  
                  for(int counter = 0; counter < numOfDogs; counter++)
                  {
                        Dog newDog = new Dog();
                     
                        System.out.println("Enter Dog ID: ");
                        dogId = myScanner.nextLine();
                        
                        System.out.println("Enter Dog Name: ");
                        dogName = myScanner.nextLine();
                        
                        newDog.setId(Integer.parseInt(dogId));
                        newDog.setName(dogName);
                        
                        subArrayDog.add(newDog);
                  }
                        
                  TextFileManager.PutTextToTextFileDog(subArrayDog);
                        
                  dogL.getList();
                  System.out.println("Succesfully saved to TextFile!");
               }
               
               if(selection == '2')
               {
                  TextFileManager.ViewTextFileEntriesDog();
               }
               
               if(selection == '3')
               {
                  int found = 0;
                  myScanner.nextLine();
                  System.out.println("Enter Dog ID to Update:" );
                  dogId = myScanner.nextLine();
                  
                  found = dogL.getIndex(Integer.parseInt(dogId));

                  
                  if(found == -1)
                  {
                     System.out.println("Dog ID not found!");
                  }
                  else
                  {
                     System.out.println("Dog ID found!");
                     Dog returnDog = dogL.getDogs(found);
                     
                     System.out.println("Enter new name: ");
                     dogName = myScanner.nextLine();
                     returnDog.setName(dogName);
                     
                     subArrayDog.set(found, returnDog);
                     TextFileManager.PutTextToTextFileDog(subArrayDog);
                  }
               }
               if(selection == '4')
               {
                  myScanner.nextLine();
                  System.out.println("Enter Dog ID to Delete: " );
                  dogId = myScanner.nextLine();
                  
                  int found = dogL.getIndex(Integer.parseInt(dogId));
                  
                  if(found == -1)
                  {
                     System.out.println("Dog ID not found!");
                  }
                  else
                  {
                     System.out.println("Dog ID found!");
                     subArrayDog.remove(found);
                     TextFileManager.PutTextToTextFileDog(subArrayDog);
                  }
               }
               
            }
            while(selection != '5');
         }
      }
      while(selection != '3');
   }
}