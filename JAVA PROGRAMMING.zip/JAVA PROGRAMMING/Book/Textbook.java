public class Textbook
{
   private int gradeLevel;
   public Textbook(int gradeLevel)
   {
      this.gradeLevel=gradeLevel;
   }
   //getters
   public int getGradeLevel()
   {
      return gradeLevel;
   }
   //setters
   public void setGradeLevel(int gradeLevel)
   {
      this.gradeLevel=gradeLevel;
   }
}