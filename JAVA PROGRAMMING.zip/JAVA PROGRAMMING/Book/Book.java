public class Book
{
   private String title;
   private int numberPage;
   
   public Book(String title, int numberPage)
   {
      this.title = title;
      this.numberPage = numberPage;
   }
   //getters
   public String getTitle()
   {
      return title;
   }
   public int getNumberPage()
   {
      return numberPage;
   }
   //setters
   public void setTtitle(String title)
   {
      this.title= title;
   }
   public void setNumberPage(int numberPage)
   {
      this.numberPage= numberPage;
   }
}