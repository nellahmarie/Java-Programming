public class IceCreamConeException extends Exception
{
   public IceCreamConeException(String message)
   {
      super(message);
   }
}