import java.util.*;
import java.util.Scanner;

public class IceCreamCone
{
   public String flavor;
   public int scoops;
   
   public IceCreamCone()
   {       
      setFlavor();
      setScoops();
   }
   public void setFlavor()
   {
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter Flavor: ");
      String flavor = sc.nextLine();
      
         if(!flavor.equalsIgnoreCase("Chocolate")&&!flavor.equalsIgnoreCase("Ube") && !flavor.equalsIgnoreCase("Vanilla"))
         {
         
            try
            {
               throw new IceCreamConeException("Invalid flavor!. Flavor must be Chocolate, Ube, and Vanilla");
            }
            catch(IceCreamConeException e)
            {
               System.out.println(e.getMessage());
               setFlavor();
            }
        }
        else
       {
         this.flavor=flavor;
       }
   }
   
   public void setScoops()
   {
       Scanner sc = new Scanner(System.in);
      System.out.println("Enter the number of scoops: ");
      int scoops = sc.nextInt();
      
      if(scoops > 3)
      {
         try
         {
            throw new IceCreamConeException("Invalid number of scoops ");
         }
         catch(IceCreamConeException e)
         {
            System.out.println(e.getMessage());
            setScoops();
         }
      }
      else
      {
         this.scoops=scoops;
      }
   }
   
   public String getFlavor()
   {
      return flavor;
   }
   public int getScoops()
   {
      return scoops;
   }
}