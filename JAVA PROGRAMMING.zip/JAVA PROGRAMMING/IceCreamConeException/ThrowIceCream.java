public class ThrowIceCream 
{
    public static void main(String[] args) 
    {
        //ice cream cone 1
        IceCreamCone iceCream1 = new IceCreamCone();
        System.out.println("Ice Cream 1: " + iceCream1.getFlavor() + " with " + iceCream1.getScoops() + " scoops.");
        //ice cream cone 2
        IceCreamCone iceCream2 = new IceCreamCone();
        System.out.println("Ice Cream 2: " + iceCream2.getFlavor() + " with " + iceCream2.getScoops() + " scoops.");
        //ice cream cone 3
        IceCreamCone iceCream3 = new IceCreamCone();
        System.out.println("Ice Cream 3: " + iceCream3.getFlavor() + " with " + iceCream3.getScoops() + " scoops.");
        
        
        
    }
}
