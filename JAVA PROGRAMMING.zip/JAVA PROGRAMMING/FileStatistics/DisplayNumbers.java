import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class DisplayNumbers {
    public static void main(String[] args) {
        String fileName = "/Users/mariloucantilado/Desktop/FileStatistics/phoneList.txt";
        Scanner scanner = new Scanner(System.in);
        boolean quit = false;

        while (!quit) {
            System.out.print("Enter friend's name (or 'q' to quit): ");
            String friendName = scanner.nextLine();

            if (friendName.equalsIgnoreCase("q")) {
                quit = true;
            } else {
                try {
                    BufferedReader reader = new BufferedReader(new FileReader(fileName));
                    String line;
                    boolean found = false;
                    String phoneNumber = "";

                    while ((line = reader.readLine()) != null) {
                        String[] parts = line.split("\t");
                        String name = parts[0];

                        if (parts.length >= 2) {
                            phoneNumber = parts[1];
                        } else {
                            phoneNumber = "N/A";
                        }

                        if (name.equalsIgnoreCase(friendName)) {
                            System.out.println("Phone number for " + name + ": " + phoneNumber);
                            found = true;
                            break;
                        }
                    }

                    reader.close();

                    if (!found) {
                        System.out.println("Could not find phone number for " + friendName);
                    }
                } catch (IOException e) {
                    System.out.println("Error occurred while reading the phone list.");
                    e.printStackTrace();
                }
            }
        }

        scanner.close();
    }
}
