import java.io.File;
import java.util.Scanner;

public class DisplaySavedPhoneList {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String fileName;

        System.out.print("Enter the file name: ");
        fileName = input.nextLine();

        try {
            Scanner fileInput = new Scanner(new File(fileName));

            while (fileInput.hasNextLine()) {
                String line = fileInput.nextLine();
                System.out.println(line);
            }

            fileInput.close();
        } catch (Exception e) {
            System.out.println("Error reading file.");
            e.printStackTrace();
        }
    }
}
