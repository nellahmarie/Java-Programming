import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileStatistics {
    public static void main(String[] args) {
        // Enter the file path of the file you want to analyze
        String filePath = "/Users/mariloucantilado/Desktop/FileStatistics/file.rtf";

        // Create a file object from the file path
        File file = new File(filePath);

        // Get the file name
        String fileName = file.getName();

        // Get the parent directory of the file
        String parent = file.getParent();

        // Get the file size in bytes
        long fileSize = file.length();

        // Get the time of last modification
        long lastModified = file.lastModified();

        // Convert the time of last modification to a human-readable format
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
        Date date = new Date(lastModified);
        String formattedDate = sdf.format(date);

        // Display the file statistics
        System.out.println("File name: " + fileName);
        System.out.println("Parent directory: " + parent);
        System.out.println("File size: " + fileSize + " bytes");
        System.out.println("Last modified: " + formattedDate);
    }
}
