import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class CreatePhoneList {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String fileName;

        System.out.print("Enter the file name: ");
        fileName = input.nextLine();

        try {
            PrintWriter outputFile = new PrintWriter(new File(fileName));

            while (true) {
                System.out.print("Enter a friend's name (or 'exit' to quit): ");
                String name = input.nextLine();
                if (name.equals("exit")) break;

                System.out.print("Enter " + name + "'s phone number: ");
                String phoneNumber = input.nextLine();

                PhoneList friend = new PhoneList(name, phoneNumber);
                outputFile.println(friend);
            }

            outputFile.close();
            System.out.println("File created successfully.");
        } catch (Exception e) {
            System.out.println("Error creating file.");
            e.printStackTrace();
        }
    }
}
