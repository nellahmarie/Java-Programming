import java.io.File;

public class FileStatistics2 {
    public static void main(String[] args) {
        // Replace these with the file paths of the two files you want to check
        String textFilePath = "/Users/mariloucantilado/Desktop/FileStatistics/qoute.rtf";
        String wordFilePath = "/Users/mariloucantilado/Desktop/FileStatistics/qoute.docx";

        // Create File objects for the two files
        File textFile = new File(textFilePath);
        File wordFile = new File(wordFilePath);

        // Get the sizes of each file in bytes
        long textSize = textFile.length();
        long wordSize = wordFile.length();

        // Calculate the ratio of the sizes
        double ratio = (double) wordSize / textSize;

        // Display the sizes and ratio
        System.out.println("Text file size: " + textSize + " bytes");
        System.out.println("Word file size: " + wordSize + " bytes");
        System.out.println("Ratio: " + ratio);
    }
}
